<?php
    class equipos {
        public $id=0;
        public $nombreEquipo="";
        public $estudiante1="";
        public $estudiante2="";
        public $estudiante3="";

        
    }
    
?>