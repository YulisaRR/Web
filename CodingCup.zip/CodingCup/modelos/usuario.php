<?php
    class Usuario{
        public $id=0;
        public $nombre="";
        public $correo="";
        public $password="";
        public $institucion="";
        public $tipo="";
    }
?>